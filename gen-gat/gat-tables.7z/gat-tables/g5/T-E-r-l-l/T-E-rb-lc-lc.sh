#/bin/bash

echo -n ' ' && echo te{m,l,c}{y,p}{y,p}$'\n'

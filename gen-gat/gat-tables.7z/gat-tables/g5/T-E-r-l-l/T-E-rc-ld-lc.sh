#/bin/bash

echo -n ' ' && echo te{d,g,f}{q,j}{y,p}$'\n'

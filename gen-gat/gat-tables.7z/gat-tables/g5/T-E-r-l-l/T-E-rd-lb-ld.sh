#/bin/bash

echo -n ' ' && echo te{v,b,w}{u,k,x}{q,j}$'\n'

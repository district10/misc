#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{q,j}{y,p}$'\n'

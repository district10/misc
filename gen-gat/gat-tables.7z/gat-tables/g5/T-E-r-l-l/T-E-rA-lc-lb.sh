#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{y,p}{u,k,x}$'\n'

#/bin/bash

echo -n ' ' && echo te{m,l,c}{u,k,x}{u,k,x}$'\n'

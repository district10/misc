#/bin/bash

echo -n ' ' && echo te{m,l,c}{y,p}{u,k,x}$'\n'

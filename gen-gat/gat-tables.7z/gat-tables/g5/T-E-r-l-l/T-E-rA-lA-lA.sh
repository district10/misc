#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{e,i,o,a,h}{e,i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo te{v,b,w}{e,i,o,a,h}{q,j}$'\n'

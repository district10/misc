#/bin/bash

echo -n ' ' && echo te{m,l,c}{e,i,o,a,h}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo te{d,g,f}{y,p}{q,j}$'\n'

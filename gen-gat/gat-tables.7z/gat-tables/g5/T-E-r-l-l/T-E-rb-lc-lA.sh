#/bin/bash

echo -n ' ' && echo te{m,l,c}{y,p}{e,i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo te{v,b,w}{y,p}{u,k,x}$'\n'

#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{q,j}{u,k,x}$'\n'

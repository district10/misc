#/bin/bash

echo -n ' ' && echo te{d,g,f}{e,i,o,a,h}{e,i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo te{m,l,c}{q,j}{e,i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo te{d,g,f}{u,k,x}{u,k,x}$'\n'

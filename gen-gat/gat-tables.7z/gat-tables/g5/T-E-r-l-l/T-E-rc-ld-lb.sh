#/bin/bash

echo -n ' ' && echo te{d,g,f}{q,j}{u,k,x}$'\n'

#/bin/bash

echo -n ' ' && echo te{d,g,f}{u,k,x}{e,i,o,a,h}$'\n'

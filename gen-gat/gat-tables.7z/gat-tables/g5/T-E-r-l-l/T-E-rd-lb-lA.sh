#/bin/bash

echo -n ' ' && echo te{v,b,w}{u,k,x}{e,i,o,a,h}$'\n'

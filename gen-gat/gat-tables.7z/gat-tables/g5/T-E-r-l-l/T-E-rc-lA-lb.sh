#/bin/bash

echo -n ' ' && echo te{d,g,f}{e,i,o,a,h}{u,k,x}$'\n'

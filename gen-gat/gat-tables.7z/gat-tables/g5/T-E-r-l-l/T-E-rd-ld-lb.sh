#/bin/bash

echo -n ' ' && echo te{v,b,w}{q,j}{u,k,x}$'\n'

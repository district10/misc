#/bin/bash

echo -n ' ' && echo te{m,l,c}{u,k,x}{q,j}$'\n'

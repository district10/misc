#/bin/bash

echo -n ' ' && echo te{m,l,c}{q,j}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo te{v,b,w}{q,j}{e,i,o,a,h}$'\n'

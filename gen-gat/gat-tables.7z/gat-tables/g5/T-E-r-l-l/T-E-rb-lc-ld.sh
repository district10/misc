#/bin/bash

echo -n ' ' && echo te{m,l,c}{y,p}{q,j}$'\n'

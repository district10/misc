#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{u,k,x}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{m,l,c}{e,i,o,a,h}{y,p}$'\n'

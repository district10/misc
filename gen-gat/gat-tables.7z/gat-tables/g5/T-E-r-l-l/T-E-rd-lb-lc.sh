#/bin/bash

echo -n ' ' && echo te{v,b,w}{u,k,x}{y,p}$'\n'

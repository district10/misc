#/bin/bash

echo -n ' ' && echo te{d,g,f}{q,j}{q,j}$'\n'

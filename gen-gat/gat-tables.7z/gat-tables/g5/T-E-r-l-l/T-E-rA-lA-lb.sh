#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{e,i,o,a,h}{u,k,x}$'\n'

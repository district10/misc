#/bin/bash

echo -n ' ' && echo te{d,g,f}{y,p}{e,i,o,a,h}$'\n'

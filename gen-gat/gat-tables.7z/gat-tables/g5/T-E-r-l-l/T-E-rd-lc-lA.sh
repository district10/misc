#/bin/bash

echo -n ' ' && echo te{v,b,w}{y,p}{e,i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo te{d,g,f}{u,k,x}{y,p}$'\n'

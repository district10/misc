#/bin/bash

echo -n ' ' && echo te{d,g,f}{u,k,x}{q,j}$'\n'

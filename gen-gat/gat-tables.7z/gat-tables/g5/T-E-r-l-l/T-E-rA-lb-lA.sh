#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{u,k,x}{e,i,o,a,h}$'\n'

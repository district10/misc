#/bin/bash

echo -n ' ' && echo te{d,g,f}{q,j}{e,i,o,a,h}$'\n'

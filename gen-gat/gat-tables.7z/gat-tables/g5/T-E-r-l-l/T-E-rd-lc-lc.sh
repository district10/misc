#/bin/bash

echo -n ' ' && echo te{v,b,w}{y,p}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{y,p}{e,i,o,a,h}$'\n'

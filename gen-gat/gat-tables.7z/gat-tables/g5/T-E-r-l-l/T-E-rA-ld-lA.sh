#/bin/bash

echo -n ' ' && echo te{t,r,s,n}{q,j}{e,i,o,a,h}$'\n'

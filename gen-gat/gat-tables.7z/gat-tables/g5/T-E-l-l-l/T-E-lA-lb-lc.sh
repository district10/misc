#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{u,k,x}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{q,j}{e,i,o,a,h}{u,k,x}$'\n'

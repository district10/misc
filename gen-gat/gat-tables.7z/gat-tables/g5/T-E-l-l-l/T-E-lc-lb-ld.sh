#/bin/bash

echo -n ' ' && echo te{y,p}{u,k,x}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo te{u,k,x}{q,j}{e,i,o,a,h}$'\n'

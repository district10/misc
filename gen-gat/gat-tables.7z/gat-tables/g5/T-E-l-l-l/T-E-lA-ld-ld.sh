#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{q,j}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo te{y,p}{q,j}{e,i,o,a,h}$'\n'

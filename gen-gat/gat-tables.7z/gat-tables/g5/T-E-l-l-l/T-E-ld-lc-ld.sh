#/bin/bash

echo -n ' ' && echo te{q,j}{y,p}{q,j}$'\n'

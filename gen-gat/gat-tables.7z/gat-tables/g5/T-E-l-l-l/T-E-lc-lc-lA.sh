#/bin/bash

echo -n ' ' && echo te{y,p}{y,p}{e,i,o,a,h}$'\n'

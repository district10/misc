#/bin/bash

echo -n ' ' && echo te{q,j}{y,p}{e,i,o,a,h}$'\n'

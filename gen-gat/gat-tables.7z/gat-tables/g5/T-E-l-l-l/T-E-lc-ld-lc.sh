#/bin/bash

echo -n ' ' && echo te{y,p}{q,j}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{e,i,o,a,h}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{y,p}{y,p}{q,j}$'\n'

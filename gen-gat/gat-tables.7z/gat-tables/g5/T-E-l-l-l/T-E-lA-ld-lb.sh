#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{q,j}{u,k,x}$'\n'

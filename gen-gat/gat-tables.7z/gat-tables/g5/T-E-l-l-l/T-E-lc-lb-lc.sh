#/bin/bash

echo -n ' ' && echo te{y,p}{u,k,x}{y,p}$'\n'

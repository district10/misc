#/bin/bash

echo -n ' ' && echo te{u,k,x}{q,j}{u,k,x}$'\n'

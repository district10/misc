#/bin/bash

echo -n ' ' && echo te{y,p}{q,j}{u,k,x}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{u,k,x}{u,k,x}$'\n'

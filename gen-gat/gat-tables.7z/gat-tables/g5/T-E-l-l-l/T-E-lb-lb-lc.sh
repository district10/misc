#/bin/bash

echo -n ' ' && echo te{u,k,x}{u,k,x}{y,p}$'\n'

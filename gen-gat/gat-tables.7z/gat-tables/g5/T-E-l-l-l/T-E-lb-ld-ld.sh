#/bin/bash

echo -n ' ' && echo te{u,k,x}{q,j}{q,j}$'\n'

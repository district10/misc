#/bin/bash

echo -n ' ' && echo te{u,k,x}{e,i,o,a,h}{u,k,x}$'\n'

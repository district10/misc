#/bin/bash

echo -n ' ' && echo te{q,j}{u,k,x}{u,k,x}$'\n'

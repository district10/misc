#/bin/bash

echo -n ' ' && echo te{y,p}{e,i,o,a,h}{u,k,x}$'\n'

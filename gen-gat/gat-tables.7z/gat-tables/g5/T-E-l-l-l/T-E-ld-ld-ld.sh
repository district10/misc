#/bin/bash

echo -n ' ' && echo te{q,j}{q,j}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo te{q,j}{y,p}{u,k,x}$'\n'

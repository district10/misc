#/bin/bash

echo -n ' ' && echo te{y,p}{e,i,o,a,h}{e,i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{y,p}{u,k,x}$'\n'

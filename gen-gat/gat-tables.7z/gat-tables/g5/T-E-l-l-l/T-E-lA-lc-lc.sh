#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{y,p}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{q,j}{y,p}{y,p}$'\n'

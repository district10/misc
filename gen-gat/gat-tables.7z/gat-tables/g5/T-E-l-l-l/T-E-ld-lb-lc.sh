#/bin/bash

echo -n ' ' && echo te{q,j}{u,k,x}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{u,k,x}{e,i,o,a,h}$'\n'

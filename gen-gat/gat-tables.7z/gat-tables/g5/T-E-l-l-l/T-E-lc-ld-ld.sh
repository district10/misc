#/bin/bash

echo -n ' ' && echo te{y,p}{q,j}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo te{y,p}{y,p}{u,k,x}$'\n'

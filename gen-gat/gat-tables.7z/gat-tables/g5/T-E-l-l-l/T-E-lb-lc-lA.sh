#/bin/bash

echo -n ' ' && echo te{u,k,x}{y,p}{e,i,o,a,h}$'\n'

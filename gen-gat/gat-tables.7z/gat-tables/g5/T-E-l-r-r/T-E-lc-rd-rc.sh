#/bin/bash

echo -n ' ' && echo te{y,p}{v,b,w}{d,g,f}$'\n'

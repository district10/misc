#/bin/bash

echo -n ' ' && echo te{u,k,x}{t,r,s,n}{t,r,s,n}$'\n'

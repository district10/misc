#/bin/bash

echo -n ' ' && echo te{y,p}{t,r,s,n}{t,r,s,n}$'\n'

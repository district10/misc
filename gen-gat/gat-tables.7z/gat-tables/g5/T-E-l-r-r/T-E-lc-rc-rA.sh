#/bin/bash

echo -n ' ' && echo te{y,p}{d,g,f}{t,r,s,n}$'\n'

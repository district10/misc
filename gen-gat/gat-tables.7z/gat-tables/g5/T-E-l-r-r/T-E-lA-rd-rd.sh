#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{v,b,w}{v,b,w}$'\n'

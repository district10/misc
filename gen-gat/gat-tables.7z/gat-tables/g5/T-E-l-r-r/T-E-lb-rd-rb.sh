#/bin/bash

echo -n ' ' && echo te{u,k,x}{v,b,w}{m,l,c}$'\n'

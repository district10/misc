#/bin/bash

echo -n ' ' && echo te{q,j}{m,l,c}{d,g,f}$'\n'

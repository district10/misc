#/bin/bash

echo -n ' ' && echo te{q,j}{v,b,w}{d,g,f}$'\n'

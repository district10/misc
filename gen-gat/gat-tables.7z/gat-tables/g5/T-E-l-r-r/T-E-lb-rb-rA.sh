#/bin/bash

echo -n ' ' && echo te{u,k,x}{m,l,c}{t,r,s,n}$'\n'

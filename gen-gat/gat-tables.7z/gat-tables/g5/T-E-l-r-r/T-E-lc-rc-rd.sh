#/bin/bash

echo -n ' ' && echo te{y,p}{d,g,f}{v,b,w}$'\n'

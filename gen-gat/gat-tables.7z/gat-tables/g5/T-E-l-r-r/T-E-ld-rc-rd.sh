#/bin/bash

echo -n ' ' && echo te{q,j}{d,g,f}{v,b,w}$'\n'

#/bin/bash

echo -n ' ' && echo te{q,j}{v,b,w}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo te{y,p}{t,r,s,n}{v,b,w}$'\n'

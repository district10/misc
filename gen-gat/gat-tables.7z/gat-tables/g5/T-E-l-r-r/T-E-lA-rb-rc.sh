#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{m,l,c}{d,g,f}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{d,g,f}{m,l,c}$'\n'

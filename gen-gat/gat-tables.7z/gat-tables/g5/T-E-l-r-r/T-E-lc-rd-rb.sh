#/bin/bash

echo -n ' ' && echo te{y,p}{v,b,w}{m,l,c}$'\n'

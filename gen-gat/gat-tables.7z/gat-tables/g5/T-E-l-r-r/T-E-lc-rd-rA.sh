#/bin/bash

echo -n ' ' && echo te{y,p}{v,b,w}{t,r,s,n}$'\n'

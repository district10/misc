#/bin/bash

echo -n ' ' && echo te{u,k,x}{d,g,f}{t,r,s,n}$'\n'

#/bin/bash

echo -n ' ' && echo te{u,k,x}{v,b,w}{v,b,w}$'\n'

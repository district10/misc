#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{d,g,f}{v,b,w}$'\n'

#/bin/bash

echo -n ' ' && echo te{q,j}{m,l,c}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{m,l,c}{v,b,w}$'\n'

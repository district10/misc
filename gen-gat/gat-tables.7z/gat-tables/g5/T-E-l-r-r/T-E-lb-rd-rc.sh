#/bin/bash

echo -n ' ' && echo te{u,k,x}{v,b,w}{d,g,f}$'\n'

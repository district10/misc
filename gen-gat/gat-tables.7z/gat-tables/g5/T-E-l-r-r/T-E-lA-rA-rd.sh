#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{t,r,s,n}{v,b,w}$'\n'

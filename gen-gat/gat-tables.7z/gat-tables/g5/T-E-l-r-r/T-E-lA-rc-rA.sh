#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{d,g,f}{t,r,s,n}$'\n'

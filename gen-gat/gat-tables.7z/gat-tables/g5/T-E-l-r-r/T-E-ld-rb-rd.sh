#/bin/bash

echo -n ' ' && echo te{q,j}{m,l,c}{v,b,w}$'\n'

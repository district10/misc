#/bin/bash

echo -n ' ' && echo te{q,j}{t,r,s,n}{t,r,s,n}$'\n'

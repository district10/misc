#/bin/bash

echo -n ' ' && echo te{q,j}{d,g,f}{d,g,f}$'\n'

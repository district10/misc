#/bin/bash

echo -n ' ' && echo te{q,j}{m,l,c}{t,r,s,n}$'\n'

#/bin/bash

echo -n ' ' && echo te{q,j}{d,g,f}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo te{y,p}{m,l,c}{m,l,c}$'\n'

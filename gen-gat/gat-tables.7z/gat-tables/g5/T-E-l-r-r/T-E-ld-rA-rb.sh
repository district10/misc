#/bin/bash

echo -n ' ' && echo te{q,j}{t,r,s,n}{m,l,c}$'\n'

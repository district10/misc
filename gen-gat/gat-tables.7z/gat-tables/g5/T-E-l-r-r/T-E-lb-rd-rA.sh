#/bin/bash

echo -n ' ' && echo te{u,k,x}{v,b,w}{t,r,s,n}$'\n'

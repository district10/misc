#/bin/bash

echo -n ' ' && echo te{u,k,x}{m,l,c}{m,l,c}$'\n'

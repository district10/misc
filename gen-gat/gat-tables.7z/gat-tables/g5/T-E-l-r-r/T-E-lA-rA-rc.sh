#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{t,r,s,n}{d,g,f}$'\n'

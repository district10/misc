#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{d,g,f}{d,g,f}$'\n'

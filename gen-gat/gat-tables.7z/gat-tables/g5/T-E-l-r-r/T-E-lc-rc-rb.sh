#/bin/bash

echo -n ' ' && echo te{y,p}{d,g,f}{m,l,c}$'\n'

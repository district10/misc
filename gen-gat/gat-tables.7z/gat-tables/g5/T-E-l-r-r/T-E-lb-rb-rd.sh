#/bin/bash

echo -n ' ' && echo te{u,k,x}{m,l,c}{v,b,w}$'\n'

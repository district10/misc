#/bin/bash

echo -n ' ' && echo te{y,p}{t,r,s,n}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{v,b,w}{m,l,c}$'\n'

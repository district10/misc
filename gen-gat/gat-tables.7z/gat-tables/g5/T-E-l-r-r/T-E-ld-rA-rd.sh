#/bin/bash

echo -n ' ' && echo te{q,j}{t,r,s,n}{v,b,w}$'\n'

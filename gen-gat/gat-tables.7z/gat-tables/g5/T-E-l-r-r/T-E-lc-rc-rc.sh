#/bin/bash

echo -n ' ' && echo te{y,p}{d,g,f}{d,g,f}$'\n'

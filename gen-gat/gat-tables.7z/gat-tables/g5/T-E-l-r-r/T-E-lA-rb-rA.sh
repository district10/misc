#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{m,l,c}{t,r,s,n}$'\n'

#/bin/bash

echo -n ' ' && echo te{e,i,o,a,h}{t,r,s,n}{t,r,s,n}$'\n'

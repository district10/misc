#/bin/bash

echo -n ' ' && echo te{y,p}{v,b,w}{v,b,w}$'\n'

#/bin/bash

echo -n ' ' && echo t{y,p}{y,p}$'\n'

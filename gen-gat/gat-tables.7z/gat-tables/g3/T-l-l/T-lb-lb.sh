#/bin/bash

echo -n ' ' && echo t{u,k,x}{u,k,x}$'\n'

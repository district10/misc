#/bin/bash

echo -n ' ' && echo t{q,j}{q,j}$'\n'

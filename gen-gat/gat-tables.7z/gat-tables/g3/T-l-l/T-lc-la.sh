#/bin/bash

echo -n ' ' && echo t{y,p}{i,o,a,h}$'\n'

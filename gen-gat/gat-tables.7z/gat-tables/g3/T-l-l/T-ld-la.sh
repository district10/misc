#/bin/bash

echo -n ' ' && echo t{q,j}{i,o,a,h}$'\n'

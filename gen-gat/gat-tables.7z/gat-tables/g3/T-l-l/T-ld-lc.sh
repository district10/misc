#/bin/bash

echo -n ' ' && echo t{q,j}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo t{q,j}{u,k,x}$'\n'

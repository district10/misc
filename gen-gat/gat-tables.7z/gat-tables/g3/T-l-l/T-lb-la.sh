#/bin/bash

echo -n ' ' && echo t{u,k,x}{i,o,a,h}$'\n'

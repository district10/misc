#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{u,k,x}$'\n'

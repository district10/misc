#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{q,j}$'\n'

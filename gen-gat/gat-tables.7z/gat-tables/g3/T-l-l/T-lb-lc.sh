#/bin/bash

echo -n ' ' && echo t{u,k,x}{y,p}$'\n'

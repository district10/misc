#/bin/bash

echo -n ' ' && echo t{y,p}{u,k,x}$'\n'

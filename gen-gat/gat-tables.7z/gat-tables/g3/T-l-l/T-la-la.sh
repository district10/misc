#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo t{u,k,x}{q,j}$'\n'

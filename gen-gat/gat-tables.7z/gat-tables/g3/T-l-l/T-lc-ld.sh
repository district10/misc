#/bin/bash

echo -n ' ' && echo t{y,p}{q,j}$'\n'

#/bin/bash

echo -n ' ' && echo t{y,p}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo t{u,k,x}{m,l,c}$'\n'

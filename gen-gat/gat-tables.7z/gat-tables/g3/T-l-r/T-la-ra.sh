#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{r,s,n}$'\n'

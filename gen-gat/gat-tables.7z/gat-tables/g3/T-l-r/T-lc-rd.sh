#/bin/bash

echo -n ' ' && echo t{y,p}{v,b,w}$'\n'

#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{v,b,w}$'\n'

#/bin/bash

echo -n ' ' && echo t{q,j}{d,g,f}$'\n'

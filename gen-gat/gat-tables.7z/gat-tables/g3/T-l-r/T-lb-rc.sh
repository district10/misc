#/bin/bash

echo -n ' ' && echo t{u,k,x}{d,g,f}$'\n'

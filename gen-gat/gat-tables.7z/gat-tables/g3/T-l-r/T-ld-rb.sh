#/bin/bash

echo -n ' ' && echo t{q,j}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo t{q,j}{r,s,n}$'\n'

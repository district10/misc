#/bin/bash

echo -n ' ' && echo t{u,k,x}{v,b,w}$'\n'

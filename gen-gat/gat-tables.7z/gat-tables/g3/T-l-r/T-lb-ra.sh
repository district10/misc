#/bin/bash

echo -n ' ' && echo t{u,k,x}{r,s,n}$'\n'

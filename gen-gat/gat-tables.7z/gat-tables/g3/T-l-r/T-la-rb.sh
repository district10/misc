#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo t{i,o,a,h}{d,g,f}$'\n'

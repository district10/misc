#/bin/bash

echo -n ' ' && echo t{y,p}{r,s,n}$'\n'

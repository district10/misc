#/bin/bash

echo -n ' ' && echo t{q,j}{v,b,w}$'\n'

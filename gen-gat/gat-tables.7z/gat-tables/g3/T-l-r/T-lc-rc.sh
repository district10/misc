#/bin/bash

echo -n ' ' && echo t{y,p}{d,g,f}$'\n'

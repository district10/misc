#/bin/bash

echo -n ' ' && echo t{r,s,n}{i,o,a,h}$'\n'

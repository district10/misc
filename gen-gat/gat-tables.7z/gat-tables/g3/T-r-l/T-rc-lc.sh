#/bin/bash

echo -n ' ' && echo t{d,g,f}{y,p}$'\n'

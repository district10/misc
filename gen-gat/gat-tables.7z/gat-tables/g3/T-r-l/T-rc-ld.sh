#/bin/bash

echo -n ' ' && echo t{d,g,f}{q,j}$'\n'

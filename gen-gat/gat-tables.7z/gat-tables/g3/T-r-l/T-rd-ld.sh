#/bin/bash

echo -n ' ' && echo t{v,b,w}{q,j}$'\n'

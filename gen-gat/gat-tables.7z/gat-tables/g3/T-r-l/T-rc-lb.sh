#/bin/bash

echo -n ' ' && echo t{d,g,f}{u,k,x}$'\n'

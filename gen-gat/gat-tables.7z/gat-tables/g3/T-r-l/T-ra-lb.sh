#/bin/bash

echo -n ' ' && echo t{r,s,n}{u,k,x}$'\n'

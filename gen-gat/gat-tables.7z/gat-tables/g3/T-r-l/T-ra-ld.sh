#/bin/bash

echo -n ' ' && echo t{r,s,n}{q,j}$'\n'

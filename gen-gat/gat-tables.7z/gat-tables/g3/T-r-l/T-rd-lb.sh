#/bin/bash

echo -n ' ' && echo t{v,b,w}{u,k,x}$'\n'

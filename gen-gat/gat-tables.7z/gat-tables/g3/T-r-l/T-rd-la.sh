#/bin/bash

echo -n ' ' && echo t{v,b,w}{i,o,a,h}$'\n'

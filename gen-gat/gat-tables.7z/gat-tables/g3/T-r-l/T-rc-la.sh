#/bin/bash

echo -n ' ' && echo t{d,g,f}{i,o,a,h}$'\n'

#/bin/bash

echo -n ' ' && echo t{m,l,c}{y,p}$'\n'

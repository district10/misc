#/bin/bash

echo -n ' ' && echo t{r,s,n}{y,p}$'\n'

#/bin/bash

echo -n ' ' && echo t{d,g,f}{r,s,n}$'\n'

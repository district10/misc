#/bin/bash

echo -n ' ' && echo t{d,g,f}{d,g,f}$'\n'

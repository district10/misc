#/bin/bash

echo -n ' ' && echo t{r,s,n}{d,g,f}$'\n'

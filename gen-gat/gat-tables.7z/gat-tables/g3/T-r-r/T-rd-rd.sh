#/bin/bash

echo -n ' ' && echo t{v,b,w}{v,b,w}$'\n'

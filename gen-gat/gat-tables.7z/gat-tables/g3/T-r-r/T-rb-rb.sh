#/bin/bash

echo -n ' ' && echo t{m,l,c}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo t{r,s,n}{v,b,w}$'\n'

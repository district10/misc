#/bin/bash

echo -n ' ' && echo t{r,s,n}{r,s,n}$'\n'

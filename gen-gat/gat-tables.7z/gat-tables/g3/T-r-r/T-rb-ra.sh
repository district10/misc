#/bin/bash

echo -n ' ' && echo t{m,l,c}{r,s,n}$'\n'

#/bin/bash

echo -n ' ' && echo t{r,s,n}{m,l,c}$'\n'

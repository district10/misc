#/bin/bash

echo -n ' ' && echo t{v,b,w}{d,g,f}$'\n'

#/bin/bash

echo -n ' ' && echo t{m,l,c}{d,g,f}$'\n'

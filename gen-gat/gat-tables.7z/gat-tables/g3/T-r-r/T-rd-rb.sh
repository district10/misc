#/bin/bash

echo -n ' ' && echo t{v,b,w}{m,l,c}$'\n'

#/bin/bash

echo -n ' ' && echo t{d,g,f}{v,b,w}$'\n'

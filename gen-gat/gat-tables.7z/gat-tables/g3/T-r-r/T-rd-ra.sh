#/bin/bash

echo -n ' ' && echo t{v,b,w}{r,s,n}$'\n'

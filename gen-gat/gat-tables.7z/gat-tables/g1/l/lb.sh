#/bin/bash

echo -n ' ' && echo {u,k,x}$'\n'

#/bin/bash

echo -n ' ' && echo {i,o,a,h}$'\n'

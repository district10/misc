#/bin/bash

echo -n ' ' && echo {q,j}$'\n'

#/bin/bash

echo -n ' ' && echo {y,p}$'\n'

#/bin/bash

echo -n ' ' && echo {m,l,c}$'\n'

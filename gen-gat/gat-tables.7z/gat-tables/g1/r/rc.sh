#/bin/bash

echo -n ' ' && echo {d,g,f}$'\n'

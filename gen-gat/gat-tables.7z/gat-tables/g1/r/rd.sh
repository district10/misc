#/bin/bash

echo -n ' ' && echo {v,b,w}$'\n'

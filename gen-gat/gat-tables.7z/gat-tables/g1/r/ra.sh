#/bin/bash

echo -n ' ' && echo {r,s,n}$'\n'
